
<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

/* COUNTS */

$eventCount = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM events")
)['total'];

$adminCount = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM admins")
)['total'];

$studentCount = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total FROM users"
    )
)['total'];
$registrationCount = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM event_registrations")
)['total'];

$result = mysqli_query(
    $conn,
    "SELECT * FROM events ORDER BY id DESC LIMIT 5"
);
?>
<link rel="stylesheet" href="admin.css">
<div class="dashboard-container">

    <!-- HERO -->

    <div class="dashboard-hero">

        <div>
            <h1>
                Welcome,
                <?= htmlspecialchars($_SESSION['admin_name']) ?> 👋
            </h1>

            <p>
                Manage events, registrations and students from one place.
            </p>
        </div>

    </div>

    <!-- STATS -->

    <div class="stats-grid">

        <div class="stat-card">
            <h2><?= $eventCount ?></h2>
            <p>Total Events</p>
        </div>

        <div class="stat-card">
    <h2><?= $studentCount ?></h2>
    <p>Total Students</p>
</div>

        <div class="stat-card">
            <h2><?= $adminCount ?></h2>
            <p>Admins</p>
        </div>

    </div>

    <!-- QUICK ACTIONS -->

    <div class="actions">

        <a href="add_event.php" class="action-btn">
            ➕ Add Event
        </a>

        <a href="view_registrations.php" class="action-btn">
            📋 Student Registrations
        </a>

        <a href="manage_admins.php" class="action-btn">
            👨‍💼 Admins
        </a>
        <a href="event_registrations.php" class="action-btn">
        🎟️ Event Registrations
    </a>

    <a href="manage_codes.php" class="action-btn">
        🔑 Registration Codes
    </a>

    </div>

    <!-- RECENT EVENTS -->

    <div class="table-card">

        <h2>Recent Events</h2>

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

            <?php while($row = mysqli_fetch_assoc($result)){ ?>

                <tr>

                    <td><?= $row['id'] ?></td>

                    <td>
                        <?= htmlspecialchars($row['event_name']) ?>
                    </td>

                    <td>
                        <?= $row['event_date'] ?>
                    </td>

                    <td>

                        <a
                        href="edit_event.php?id=<?= $row['id'] ?>">
                            ✏️ Edit
                        </a>

                        |

                        <a
                        href="delete_event.php?id=<?= $row['id'] ?>"
                        onclick="return confirm('Delete Event?')">
                            🗑 Delete
                        </a>

                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>

</div>

