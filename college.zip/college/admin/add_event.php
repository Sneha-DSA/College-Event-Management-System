<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";

include "navbar.php";

$success = "";
$error = "";

if(isset($_POST['add'])){

    $title = mysqli_real_escape_string(
        $conn,
        $_POST['title']
    );

    $description = mysqli_real_escape_string(
        $conn,
        $_POST['description']
    );

    $location = mysqli_real_escape_string(
        $conn,
        $_POST['location']
    );

    $category = mysqli_real_escape_string(
        $conn,
        $_POST['category']
    );

    $date = $_POST['date'];

    $imageName = "";

    if(isset($_FILES['event_image'])
        && $_FILES['event_image']['error']==0){

        $imageName =
        time()."_".
        basename($_FILES['event_image']['name']);

        move_uploaded_file(
            $_FILES['event_image']['tmp_name'],
            "../uploads/".$imageName
        );
    }

    $insert = mysqli_query(

        $conn,

        "INSERT INTO events
        (
            event_name,
            event_description,
            event_location,
            event_category,
            event_date,
            event_image
        )
        VALUES
        (
            '$title',
            '$description',
            '$location',
            '$category',
            '$date',
            '$imageName'
        )"
    );

    if($insert){
        $success = "🎉 Event Added Successfully!";
    }else{
        $error = mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Add Event</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f7fb;
}

.dashboard-container{
    width:90%;
    max-width:1000px;
    margin:30px auto;
}

.hero{
    background:linear-gradient(135deg,#081229,#2563eb);
    color:white;
    padding:40px;
    border-radius:25px;
    margin-bottom:30px;
}

.hero h1{
    font-size:40px;
    margin-bottom:10px;
}

.form-card{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input,
.form-group textarea,
.form-group select{

    width:100%;
    padding:14px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
}

.form-group textarea{
    resize:none;
    height:120px;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus{
    border-color:#2563eb;
}

.upload-box{

    border:2px dashed #2563eb;
    padding:25px;
    text-align:center;
    border-radius:15px;
    cursor:pointer;
}

.preview{

    width:100%;
    max-height:300px;
    object-fit:cover;
    border-radius:15px;
    margin-top:15px;
    display:none;
}

.submit-btn{

    width:100%;
    border:none;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    padding:16px;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
}

.submit-btn:hover{
    opacity:.9;
}

.success-box{
    background:#dcfce7;
    color:#166534;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
}

</style>

</head>
<body>

<div class="dashboard-container">

    <div class="hero">

        <h1>🎉 Create New Event</h1>

        <p>
            Publish exciting college events
            for students.
        </p>

    </div>

    <div class="form-card">

        <?php if($success){ ?>
            <div class="success-box">
                <?php echo $success; ?>
            </div>
        <?php } ?>

        <?php if($error){ ?>
            <div class="error-box">
                <?php echo $error; ?>
            </div>
        <?php } ?>

        <form method="POST"
              enctype="multipart/form-data">

            <div class="form-group">

                <label>Event Title</label>

                <input
                    type="text"
                    name="title"
                    required>

            </div>

            <div class="form-group">

                <label>Description</label>

                <textarea
                    name="description"
                    required></textarea>

            </div>

            <div class="form-group">

                <label>Location</label>

                <input
                    type="text"
                    name="location"
                    required>

            </div>

            <div class="form-group">

                <label>Category</label>

                <select name="category">

                    <option>Technical</option>
                    <option>Cultural</option>
                    <option>Sports</option>
                    <option>Workshop</option>
                    <option>Seminar</option>

                </select>

            </div>

            <div class="form-group">

                <label>Event Date</label>

                <input
                    type="date"
                    name="date"
                    required>

            </div>

            <div class="form-group">

                <label>Event Banner</label>

                <div class="upload-box">

                    Select Event Image

                    <input
                        type="file"
                        name="event_image"
                        id="eventImage"
                        accept="image/*">

                </div>

                <img
                    id="preview"
                    class="preview">

            </div>

            <button
                type="submit"
                name="add"
                class="submit-btn">

                🚀 Publish Event

            </button>

        </form>

    </div>

</div>

<script>

document
.getElementById("eventImage")

.addEventListener("change",

function(e){

    const file = e.target.files[0];

    if(file){

        let reader =
        new FileReader();

        reader.onload =
        function(event){

            let preview =
            document.getElementById(
            "preview");

            preview.src =
            event.target.result;

            preview.style.display =
            "block";
        };

        reader.readAsDataURL(file);
    }

});

</script>

</body>
</html>