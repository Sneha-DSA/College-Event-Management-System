
<?php

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

$id = (int)($_GET['id'] ?? 0);

$result = mysqli_query(
    $conn,
    "SELECT * FROM events WHERE id='$id'"
);

if(mysqli_num_rows($result) == 0){
    die("Event not found");
}

$event = mysqli_fetch_assoc($result);

$success = "";
$error = "";

if(isset($_POST['update'])){

    $title = mysqli_real_escape_string(
        $conn,
        $_POST['title']
    );

    $description = mysqli_real_escape_string(
        $conn,
        $_POST['description']
    );

    $location = mysqli_real_escape_string(
        $conn,
        $_POST['location']
    );

    $category = mysqli_real_escape_string(
        $conn,
        $_POST['category']
    );

    $date = $_POST['date'];

    $imageName = $event['event_image'];

    if(
        isset($_FILES['event_image']) &&
        $_FILES['event_image']['error'] == 0
    ){

        $imageName =
        time().'_'.
        basename($_FILES['event_image']['name']);

        move_uploaded_file(
            $_FILES['event_image']['tmp_name'],
            "../uploads/".$imageName
        );
    }

    $update = mysqli_query(

        $conn,

        "UPDATE events SET

        event_name='$title',
        event_description='$description',
        event_location='$location',
        event_category='$category',
        event_date='$date',
        event_image='$imageName'

        WHERE id='$id'"
    );

    if($update){

        $success =
        "🎉 Event Updated Successfully";

        $result = mysqli_query(
            $conn,
            "SELECT * FROM events WHERE id='$id'"
        );

        $event = mysqli_fetch_assoc($result);

    }else{

        $error = mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html>
<head>

<title>Edit Event</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

body{
    background:#f4f7fb;
    font-family:Poppins,sans-serif;
}

.dashboard-container{
    width:90%;
    max-width:1000px;
    margin:30px auto;
}

.hero{
    background:linear-gradient(135deg,#081229,#2563eb);
    color:white;
    padding:40px;
    border-radius:25px;
    margin-bottom:30px;
}

.form-card{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input,
.form-group textarea,
.form-group select{
    width:100%;
    padding:14px;
    border:2px solid #e5e7eb;
    border-radius:12px;
}

.form-group textarea{
    height:120px;
    resize:none;
}

.preview{
    width:100%;
    max-height:300px;
    object-fit:cover;
    border-radius:15px;
    margin-top:15px;
}

.submit-btn{
    width:100%;
    border:none;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    padding:16px;
    border-radius:12px;
    cursor:pointer;
    font-size:16px;
    font-weight:600;
}

.success-box{
    background:#dcfce7;
    color:#166534;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
}

</style>

</head>
<body>

<div class="dashboard-container">

    <div class="hero">

        <h1>✏️ Edit Event</h1>

        <p>
            Update event information.
        </p>

    </div>

    <div class="form-card">

        <?php if($success){ ?>
            <div class="success-box">
                <?php echo $success; ?>
            </div>
        <?php } ?>

        <?php if($error){ ?>
            <div class="error-box">
                <?php echo $error; ?>
            </div>
        <?php } ?>

        <form
        method="POST"
        enctype="multipart/form-data">

            <div class="form-group">

                <label>Event Title</label>

                <input
                type="text"
                name="title"
                value="<?= htmlspecialchars($event['event_name']) ?>"
                required>

            </div>

            <div class="form-group">

                <label>Description</label>

                <textarea
                name="description"
                required><?= htmlspecialchars($event['event_description']) ?></textarea>

            </div>

            <div class="form-group">

                <label>Location</label>

                <input
                type="text"
                name="location"
                value="<?= htmlspecialchars($event['event_location']) ?>"
                required>

            </div>

            <div class="form-group">

                <label>Category</label>

                <select name="category">

                    <option <?= $event['event_category']=="Technical"?"selected":"" ?>>
                        Technical
                    </option>

                    <option <?= $event['event_category']=="Cultural"?"selected":"" ?>>
                        Cultural
                    </option>

                    <option <?= $event['event_category']=="Sports"?"selected":"" ?>>
                        Sports
                    </option>

                    <option <?= $event['event_category']=="Workshop"?"selected":"" ?>>
                        Workshop
                    </option>

                    <option <?= $event['event_category']=="Seminar"?"selected":"" ?>>
                        Seminar
                    </option>

                </select>

            </div>

            <div class="form-group">

                <label>Event Date</label>

                <input
                type="date"
                name="date"
                value="<?= $event['event_date'] ?>"
                required>

            </div>

            <div class="form-group">

                <label>Current Banner</label>

                <?php if(!empty($event['event_image'])){ ?>

                    <img
                    src="../uploads/<?= $event['event_image'] ?>"
                    class="preview">

                <?php } ?>

            </div>

            <div class="form-group">

                <label>Change Banner</label>

                <input
                type="file"
                name="event_image"
                accept="image/*">

            </div>

            <button
            type="submit"
            name="update"
            class="submit-btn">

                🚀 Update Event

            </button>

        </form>

    </div>

</div>

</body>
</html>
