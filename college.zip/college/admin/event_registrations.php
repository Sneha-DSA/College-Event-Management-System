<?php

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

/* DELETE */

if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query(
        $conn,
        "DELETE FROM event_registrations
         WHERE id='$id'"
    );

    header("Location: event_registrations.php");
    exit();
}

/* FETCH REGISTRATIONS */

$result = mysqli_query(

    $conn,

    "SELECT
        er.*,
        e.event_name
     FROM event_registrations er
     LEFT JOIN events e
     ON er.event_id = e.id
     ORDER BY er.id DESC"
);

$totalRegistrations =
mysqli_num_rows($result);

?>

<!DOCTYPE html>
<html>
<head>

<title>Event Registrations</title>

<link rel="stylesheet" href="admin.css">

</head>

<body>

<div class="dashboard-container">

    <!-- HERO -->

    <div class="dashboard-hero">

        <h1>🎟 Event Registrations</h1>

        <p>
            View all student event registrations.
        </p>

    </div>

    <!-- STATS -->

    <div class="stats-grid">

        <div class="stat-card">

            <h2>
                <?= $totalRegistrations ?>
            </h2>

            <p>
                Total Registrations
            </p>

        </div>

    </div>

    <!-- TABLE -->

    <div class="table-card">

        <h2 style="margin-bottom:20px;">
            Registration List
        </h2>

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Event</th>
                    <th>Student</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Members</th>
                    <th>Code</th>
                    <th>Date</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

            <?php

            if(mysqli_num_rows($result) > 0){

                while($row =
                mysqli_fetch_assoc($result)){

            ?>

                <tr>

                    <td>
                        <?= $row['id'] ?>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                            $row['event_name']
                        ) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                            $row['student_name']
                        ) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                            $row['student_email']
                        ) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                            $row['student_mobile']
                        ) ?>
                    </td>

                    <td>
                        <?= $row['members'] ?>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                            $row['registration_code']
                        ) ?>
                    </td>

                    <td>
                        <?= date(
                            "d M Y h:i A",
                            strtotime(
                                $row['created_at']
                            )
                        ) ?>
                    </td>

                    <td>

                        <a
                        href="?delete=<?= $row['id'] ?>"
                        class="delete-btn"
                        onclick="return confirm('Delete Registration?')">

                            🗑 Delete

                        </a>

                    </td>

                </tr>

            <?php

                }

            }else{

                echo "
                <tr>
                    <td colspan='9'>
                        No registrations found
                    </td>
                </tr>";
            }

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>