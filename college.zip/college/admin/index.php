<?php

session_start();
include "db_connect.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = "";

if(isset($_POST['login'])){

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $password = trim($_POST['password']);

    $query = mysqli_query(
        $conn,
        "SELECT * FROM admins
         WHERE email='$email'
         LIMIT 1"
    );

    if(!$query){
        die("Database Error: " . mysqli_error($conn));
    }

    if(mysqli_num_rows($query) == 1){

        $admin = mysqli_fetch_assoc($query);

        if(password_verify($password, $admin['password'])){

            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];

            header("Location: dashboard.php");
            exit();

        }else{

            $error = "❌ Invalid Password";

        }

    }else{

        $error = "❌ Admin Not Found";

    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Login</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(-45deg,#081229,#163c78,#2563eb,#4f46e5);
    background-size:400% 400%;
    animation:gradientMove 10s ease infinite;
    padding:20px;
}

@keyframes gradientMove{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

.login-container{
    width:100%;
    max-width:1050px;
    min-height:620px;
    display:grid;
    grid-template-columns:1fr 1fr;
    background:rgba(255,255,255,0.95);
    backdrop-filter:blur(15px);
    border-radius:30px;
    overflow:hidden;
    box-shadow:0 25px 70px rgba(0,0,0,0.25);
}

.login-left{
    background:linear-gradient(135deg,#081229,#2563eb);
    color:white;
    padding:60px;
    display:flex;
    flex-direction:column;
    justify-content:center;
}

.admin-icon{
    width:110px;
    height:110px;
    border-radius:50%;
    background:rgba(255,255,255,0.15);
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:50px;
    margin-bottom:30px;
}

.login-left h1{
    font-size:46px;
    margin-bottom:15px;
}

.login-left p{
    font-size:16px;
    line-height:1.8;
    color:#dbe4ff;
}

.features{
    margin-top:35px;
}

.features p{
    margin-bottom:15px;
}

.login-right{
    padding:70px 60px;
    display:flex;
    flex-direction:column;
    justify-content:center;
}

.login-right h2{
    font-size:34px;
    color:#111827;
    margin-bottom:10px;
}

.login-right .subtitle{
    color:#6b7280;
    margin-bottom:35px;
}

.form-group{
    margin-bottom:22px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input{
    width:100%;
    padding:15px;
    border:2px solid #e5e7eb;
    border-radius:14px;
    font-size:15px;
    transition:.3s;
}

.form-group input:focus{
    border-color:#2563eb;
    outline:none;
}

.login-btn{
    width:100%;
    border:none;
    padding:16px;
    border-radius:14px;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
}

.login-btn:hover{
    transform:translateY(-4px);
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:14px;
    border-radius:12px;
    margin-bottom:20px;
    text-align:center;
}

.portal-badge{
    display:inline-block;
    background:#eef2ff;
    color:#2563eb;
    padding:8px 16px;
    border-radius:30px;
    font-size:13px;
    font-weight:600;
    margin-bottom:15px;
}

@media(max-width:900px){

    .login-container{
        grid-template-columns:1fr;
    }

    .login-left{
        display:none;
    }

    .login-right{
        padding:40px 30px;
    }
}

</style>

</head>

<body>

<div class="login-container">

    <div class="login-left">

        <div class="admin-icon">
            <i class="fa-solid fa-user-shield"></i>
        </div>

        <h1>Admin Portal</h1>

        <p>
            Manage events, registrations, students,
            reports and registration codes from one dashboard.
        </p>

        <div class="features">
            <p>✔ Manage College Events</p>
            <p>✔ View Student Registrations</p>
            <p>✔ Generate Reports</p>
            <p>✔ Control Registration Codes</p>
        </div>

    </div>

    <div class="login-right">

        <span class="portal-badge">
            COLLEGE EVENT MANAGEMENT
        </span>

        <h2>Welcome Back 👋</h2>

        <p class="subtitle">
            Login to access the Admin Dashboard
        </p>

        <?php if(!empty($error)){ ?>
            <div class="error-box">
                <?= $error ?>
            </div>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Email Address</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Enter admin email"
                    required>
            </div>

            <div class="form-group">
                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Enter password"
                    required>
            </div>

            <button
                type="submit"
                name="login"
                class="login-btn">

                <i class="fa-solid fa-right-to-bracket"></i>
                Login To Dashboard

            </button>

        </form>

    </div>

</div>

</body>
</html>
```
