<?php

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

/* DELETE ADMIN */

if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    if($id != $_SESSION['admin_id']){

        mysqli_query(
            $conn,
            "DELETE FROM admins WHERE id='$id'"
        );
    }

    header("Location: manage_admins.php");
    exit();
}

/* FETCH ADMINS */

$admins = mysqli_query(
    $conn,
    "SELECT * FROM admins ORDER BY id DESC"
);

$totalAdmins = mysqli_num_rows($admins);

?>

<!DOCTYPE html>
<html>
<head>

<title>Manage Admins</title>

<link rel="stylesheet" href="admin.css">

</head>
<body>

<div class="dashboard-container">

    <!-- HERO -->

    <div class="dashboard-hero">

        <h1>👨‍💼 Manage Admins</h1>

        <p>
            View, manage and control administrator accounts.
        </p>

    </div>

    <!-- STATS -->

    <div class="stats-grid">

        <div class="stat-card">

            <h2><?php echo $totalAdmins; ?></h2>

            <p>Total Admins</p>

        </div>

    </div>

    <!-- ACTION -->

    <div class="actions">

        <a href="registrations.php"
           class="action-btn">

            ➕ Add New Admin

        </a>

    </div>

    <!-- TABLE -->

    <div class="table-card">

        <h2 style="margin-bottom:20px;">
            Admin List
        </h2>

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Name</th>

                    <th>Email</th>

                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

            <?php while($admin = mysqli_fetch_assoc($admins)){ ?>

                <tr>

                    <td>
                        <?php echo $admin['id']; ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($admin['name']); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($admin['email']); ?>
                    </td>

                    <td>

                        <?php if(
                        $admin['id']
                        !=
                        $_SESSION['admin_id']
                        ){ ?>

                        <a
                        class="delete-btn"
                        href="?delete=<?php echo $admin['id']; ?>"
                        onclick="return confirm('Delete this admin?')">

                            Delete

                        </a>

                        <?php } else { ?>

                            <span class="you-badge">
                                You
                            </span>

                        <?php } ?>

                    </td>

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>