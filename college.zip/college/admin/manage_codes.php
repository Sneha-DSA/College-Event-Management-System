<?php

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

/* DELETE CODE */

if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query(
        $conn,
        "DELETE FROM coupons WHERE id='$id'"
    );

    header("Location: manage_codes.php");
    exit();
}

/* ADD CODE */

$message = "";

if(isset($_POST['add_code'])){

    $coupon_code = mysqli_real_escape_string(
        $conn,
        strtoupper(trim($_POST['coupon_code']))
    );

    $event_id = (int)$_POST['event_id'];

    $check = mysqli_query(
        $conn,
        "SELECT id FROM coupons
         WHERE coupon_code='$coupon_code'"
    );

    if(mysqli_num_rows($check) > 0){

        $message = "❌ Code already exists";

    }else{

        mysqli_query(
            $conn,
            "INSERT INTO coupons
            (coupon_code,event_id)
            VALUES
            ('$coupon_code','$event_id')"
        );

        $message = "✅ Code Created Successfully";
    }
}

/* FETCH DATA */

$codes = mysqli_query(
    $conn,
    "SELECT c.*, e.event_name
     FROM coupons c
     LEFT JOIN events e
     ON c.event_id = e.id
     ORDER BY c.id DESC"
);

$totalCodes = mysqli_num_rows($codes);

$events = mysqli_query(
    $conn,
    "SELECT id,event_name
     FROM events
     ORDER BY event_name ASC"
);

?>

<!DOCTYPE html>
<html>
<head>

<title>Manage Codes</title>

<link rel="stylesheet" href="admin.css">

</head>
<body>

<div class="dashboard-container">

    <div class="dashboard-hero">

        <h1>🔑 Registration Codes</h1>

        <p>
            Create and manage event registration codes.
        </p>

    </div>

    <div class="stats-grid">

        <div class="stat-card">

            <h2><?= $totalCodes ?></h2>

            <p>Total Codes</p>

        </div>

    </div>

    <div class="table-card">

        <h2 style="margin-bottom:20px;">
            Create New Code
        </h2>

        <?php if($message){ ?>

            <div class="success-box">
                <?= $message ?>
            </div>

        <?php } ?>

        <form method="POST">

            <div class="form-group">

                <label>Registration Code</label>

                <input
                type="text"
                name="coupon_code"
                placeholder="Example: TECH2026"
                required>

            </div>

            <div class="form-group">

                <label>Select Event</label>

                <select name="event_id" required>

                    <option value="">
                        Choose Event
                    </option>

                    <?php
                    mysqli_data_seek($events,0);

                    while($event =
                    mysqli_fetch_assoc($events)){
                    ?>

                    <option
                    value="<?= $event['id'] ?>">

                        <?= htmlspecialchars(
                        $event['event_name']
                        ) ?>

                    </option>

                    <?php } ?>

                </select>

            </div>

            <button
            type="submit"
            name="add_code"
            class="action-btn">

                ➕ Create Code

            </button>

        </form>

    </div>

    <br><br>

    <div class="table-card">

        <h2 style="margin-bottom:20px;">
            Existing Codes
        </h2>

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Code</th>
                    <th>Event</th>
                    <th>Created</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

            <?php

            if(mysqli_num_rows($codes)>0){

                while($row =
                mysqli_fetch_assoc($codes)){

            ?>

                <tr>

                    <td>
                        <?= $row['id'] ?>
                    </td>

                    <td>
                        <strong>
                        <?= htmlspecialchars(
                        $row['coupon_code']
                        ) ?>
                        </strong>
                    </td>

                    <td>
                        <?= htmlspecialchars(
                        $row['event_name']
                        ) ?>
                    </td>

                    <td>
                        <?= date(
                        "d M Y",
                        strtotime(
                        $row['created_at']
                        )) ?>
                    </td>

                    <td>

                        <a
                        href="?delete=<?= $row['id'] ?>"
                        onclick="return confirm('Delete Code?')"
                        class="delete-btn">

                            Delete

                        </a>

                    </td>

                </tr>

            <?php

                }

            }else{

                echo "
                <tr>
                    <td colspan='5'>
                    No codes found
                    </td>
                </tr>";
            }

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>