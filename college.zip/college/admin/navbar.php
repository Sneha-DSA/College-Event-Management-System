
<?php
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>
<link rel="stylesheet" href="admin.css">
<div class="navbar">

    <div class="logo">
        🎓 Admin Panel
    </div>

    <div class="menu">

        <a href="Dashboard.php">
            📊 Dashboard
        </a>

        <a href="add_event.php">
            ➕ Add Event
        </a>

        <a href="registrations.php">
            📝 Admin Registration
        </a>

        <a href="manage_admins.php">
            👨‍💼 Admins
        </a>

        <a href="index.php" class="logout-btn">
            🚪 Logout
        </a>

    </div>

</div>

