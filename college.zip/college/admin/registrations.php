
<?php

include "db_connect.php";

$success = "";
$error = "";

if(isset($_POST['register'])){

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'])
    );

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $check = mysqli_query(
        $conn,
        "SELECT id FROM admins
         WHERE email='$email'"
    );

    if(mysqli_num_rows($check) > 0){

        $error = "Admin already exists with this email.";

    }else{

        $insert = mysqli_query(
            $conn,
            "INSERT INTO admins
            (name,email,password)
            VALUES
            ('$name','$email','$password')"
        );

        if($insert){
            $success = "🎉 Admin Registered Successfully!";
        }else{
            $error = mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Registration</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#081229,#2563eb);
    padding:20px;
}

.register-container{
    width:100%;
    max-width:1000px;
    display:grid;
    grid-template-columns:1fr 1fr;
    background:white;
    border-radius:30px;
    overflow:hidden;
    box-shadow:0 20px 60px rgba(0,0,0,.25);
}

.left-panel{
    background:linear-gradient(135deg,#081229,#163c78);
    color:white;
    padding:60px;
    display:flex;
    flex-direction:column;
    justify-content:center;
}

.left-panel h1{
    font-size:42px;
    margin-bottom:15px;
}

.left-panel p{
    color:#dbe4ff;
    line-height:1.8;
}

.right-panel{
    padding:60px;
}

.right-panel h2{
    font-size:34px;
    margin-bottom:10px;
}

.right-panel p{
    color:#6b7280;
    margin-bottom:30px;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input{
    width:100%;
    padding:15px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
}

.form-group input:focus{
    border-color:#2563eb;
}

.register-btn{
    width:100%;
    border:none;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    padding:15px;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
}

.register-btn:hover{
    transform:translateY(-3px);
}

.success-box{
    background:#dcfce7;
    color:#166534;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:12px;
    border-radius:10px;
    margin-bottom:20px;
}

.admin-icon{
    font-size:70px;
    margin-bottom:20px;
}

@media(max-width:768px){

    .register-container{
        grid-template-columns:1fr;
    }

    .left-panel{
        display:none;
    }

    .right-panel{
        padding:35px;
    }
}

</style>

</head>

<body>

<div class="register-container">

    <div class="left-panel">

        <div class="admin-icon">
            <i class="fa-solid fa-user-plus"></i>
        </div>

        <h1>Admin Registration</h1>

        <p>
            Create new administrator accounts
            to manage events, registrations,
            students and reports.
        </p>

    </div>

    <div class="right-panel">

        <h2>Create Admin 👨‍💼</h2>

        <p>Add a new administrator account.</p>

        <?php if($success){ ?>
            <div class="success-box">
                <?php echo $success; ?>
            </div>
        <?php } ?>

        <?php if($error){ ?>
            <div class="error-box">
                <?php echo $error; ?>
            </div>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Full Name</label>
                <input
                    type="text"
                    name="name"
                    placeholder="Enter full name"
                    required>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input
                    type="email"
                    name="email"
                    placeholder="Enter email"
                    required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input
                    type="password"
                    name="password"
                    placeholder="Enter password"
                    required>
            </div>

            <button
                type="submit"
                name="register"
                class="register-btn">

                <i class="fa-solid fa-user-plus"></i>
                Register Admin

            </button>

        </form>

    </div>

</div>

</body>
</html>

