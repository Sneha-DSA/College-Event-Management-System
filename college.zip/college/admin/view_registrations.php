<?php

session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

include "../db_connect.php";
include "navbar.php";

/* DELETE STUDENT */

if(isset($_GET['delete'])){

    $id = (int)$_GET['delete'];

    mysqli_query(
        $conn,
        "DELETE FROM users WHERE id='$id'"
    );

    header("Location: view_registrations.php");
    exit();
}

/* SEARCH */

$search = $_GET['search'] ?? '';

$query = "
SELECT *
FROM users
WHERE full_name LIKE '%$search%'
OR email LIKE '%$search%'
ORDER BY id DESC
";

$users = mysqli_query($conn, $query);

$totalUsers = mysqli_num_rows($users);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Student Registrations</title>

<link rel="stylesheet" href="admin.css">

<style>

.search-bar{
    display:flex;
    gap:10px;
    margin-bottom:25px;
}

.search-bar input{
    flex:1;
    padding:14px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
}

.search-btn{
    border:none;
    background:#2563eb;
    color:white;
    padding:14px 20px;
    border-radius:12px;
    cursor:pointer;
}

.delete-btn{
    background:#ef4444;
    color:white;
    text-decoration:none;
    padding:8px 14px;
    border-radius:8px;
    font-size:14px;
    font-weight:600;
}

.delete-btn:hover{
    background:#dc2626;
}

.no-data{
    text-align:center;
    padding:30px;
    color:#6b7280;
}

</style>

</head>

<body>

<div class="dashboard-container">

    <!-- HERO -->

    <div class="dashboard-hero">

        <h1>👨‍🎓 Student Registrations</h1>

        <p>
            Manage all registered students.
        </p>

    </div>

    <!-- STATS -->

    <div class="stats-grid">

        <div class="stat-card">

            <h2><?php echo $totalUsers; ?></h2>

            <p>Total Students</p>

        </div>

    </div>

    <!-- SEARCH -->

    <div class="table-card">

        <form method="GET" class="search-bar">

            <input
                type="text"
                name="search"
                placeholder="Search by name or email..."
                value="<?php echo htmlspecialchars($search); ?>">

            <button
                type="submit"
                class="search-btn">

                🔍 Search

            </button>

        </form>

    </div>

    <br>

    <!-- STUDENTS TABLE -->

    <div class="table-card">

        <h2 style="margin-bottom:20px;">
            Registered Students
        </h2>

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Registered On</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

            <?php

            if(mysqli_num_rows($users) > 0){

                while($user = mysqli_fetch_assoc($users)){

            ?>

                <tr>

                    <td>
                        <?php echo $user['id']; ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars(
                            $user['full_name']
                        ); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars(
                            $user['email']
                        ); ?>
                    </td>

                    <td>
                        <?php echo date(
                            "d M Y h:i A",
                            strtotime(
                                $user['created_at']
                            )
                        ); ?>
                    </td>

                    <td>

                        <a
                        href="?delete=<?php echo $user['id']; ?>"
                        class="delete-btn"
                        onclick="return confirm('Delete this student?')">

                            🗑 Delete

                        </a>

                    </td>

                </tr>

            <?php

                }

            }else{

                echo "
                <tr>
                    <td colspan='5' class='no-data'>
                        No students found
                    </td>
                </tr>";
            }

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>