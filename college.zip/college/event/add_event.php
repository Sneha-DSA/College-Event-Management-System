<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: /college/login.php");
    exit();
}

require_once __DIR__ . "/../db_connect.php";
require_once __DIR__ . "/../navbar.php";
?>


<!DOCTYPE html>
<html>
<head>
  <title>Add Event</title>
<link rel="stylesheet" href="../css/style.css">
<style>
    body {
        background: #f3f6ff;
        font-family: 'Segoe UI', sans-serif;
    }

    .page-title {
        text-align: center;
        margin-top: 40px;
    }

    .page-title h2 {
        font-size: 34px;
        margin-bottom: 6px;
    }

    .page-title p {
        color: #555;
        font-size: 14px;
    }

    .container {
        max-width: 420px;
        margin: 40px auto;
        background: white;
        padding: 30px;
        border-radius: 18px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }

    input, textarea {
        width: 100%;
        padding: 12px;
        margin-top: 12px;
        border-radius: 8px;
        border: 1px solid #ccc;
        font-size: 14px;
    }

    textarea {
        resize: none;
        height: 100px;
    }

    button {
        width: 100%;
        margin-top: 18px;
        padding: 12px;
        background: #1f2937;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 15px;
        cursor: pointer;
    }

    button:hover {
        background: #111827;
    }
/* Hero Header like Gallery */
.hero-header {
    background: linear-gradient(90deg, #4f46e5, #6366f1);
    padding: 70px 20px;
    text-align: center;
    color: white;
}

.hero-header h1 {
    font-size: 40px;
    margin-bottom: 10px;
}

.hero-header p {
    font-size: 15px;
    opacity: 0.9;
}

/* Move form up slightly */
.form-container {
    margin-top: -40px;
}

body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f3f6ff;
}

/* TOP HEADER BOX */

.gallery-title {
    text-align: center;
    padding: 60px 20px;
    background: transparent; /* IMPORTANT */
}

.gallery-title h1 {
    font-size: 36px;
    color: #111827;
}

.gallery-title p {
    color: #6b7280;
}

/* FORM CENTER */
.container {
    display: flex;
    justify-content: center;
    margin-top: 40px;
}

/* FORM CARD */
form {
    background: white;
    width: 400px;
    padding: 30px;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

/* INPUTS */
form input,
form textarea {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 14px;
}

form textarea {
    height: 100px;
    resize: none;
}

/* BUTTON */
form button {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #1f2937;
    color: white;
    font-size: 15px;
    cursor: pointer;
}

form button:hover {
    background: #111827;
}

.site-header {
    background: linear-gradient(90deg, #4f46e5, #6366f1);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.navbar {
    max-width: 1200px;
    margin: auto;
    padding: 15px 40px;
    display: flex;
    align-items: center;
}

/* LEFT */
.nav-title {
    color: white;
    font-size: 20px;
    font-weight: 600;
}

/* RIGHT */
.nav-right {
    margin-left: auto;        /* ⭐ THIS IS THE KEY */
    display: flex;
    gap: 25px;
}

.nav-right a {
    color: white;
    text-decoration: none;
    font-weight: 500;
}
</style>
</head>

<body>

  <div class="page-hero">
    <h1>Add New Event</h1>
    <p>Create memorable moments for your campus</p>
</div>
<div class="form-wrapper">
    <div class="form-card">

    <form method="POST">
        <input type="text" name="title" placeholder="Event Title" required>
        <input type="date" name="date" required>
        <textarea name="description" placeholder="Event Description" required></textarea>
        <button type="submit">Add Event</button>
    </form>
    </div>
</div>

</div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $title = $_POST['title'];
  $date = $_POST['date'];
  $desc = $_POST['description'];

  $sql = "INSERT INTO events (title, event_date, description)
          VALUES ('$title', '$date', '$desc')";

  mysqli_query($conn, $sql);

  header("Location: /college/event/index.php");
}
?>
