<?php
include '../db_connect.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM events WHERE id=$id");
 header("Location: ../login.php");
    exit;
}
?>