<?php
include '../db_connect.php';
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}
?>
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM events WHERE id=$id");
$data = mysqli_fetch_assoc($result);

if(isset($_POST['update'])){
    $title = $_POST['title'];
    $date = $_POST['date'];
    $desc = $_POST['description'];

    mysqli_query($conn, "UPDATE events 
        SET title='$title', date='$date', description='$desc'
        WHERE id=$id");

    echo "<script>alert('Event Updated');</script>";
}
?>

<form method="POST">
    <label>Title:</label>
    <input type="text" name="title" value="<?= $data['title'] ?>"><br><br>

    <label>Date:</label>
    <input type="date" name="date" value="<?= $data['date'] ?>"><br><br>

    <label>Description:</label>
    <textarea name="description"><?= $data['description'] ?></textarea><br><br>

    <button name="update">Update Event</button>
</form>
