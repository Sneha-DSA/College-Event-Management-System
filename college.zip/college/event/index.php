<?php
include("../db_connect.php");

$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? '';

$query = "SELECT * FROM events WHERE 1";

if ($search !== '') {
    $query .= " AND event_name LIKE '%$search%'";
}

if ($filter === 'upcoming') {
    $query .= " AND event_date >= CURDATE()";
} elseif ($filter === 'past') {
    $query .= " AND event_date < CURDATE()";
}

$query .= " ORDER BY event_date DESC";
$result = mysqli_query($conn, $query);

$totalEvents = $result ? mysqli_num_rows($result) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>All Events</title>
    <link rel="stylesheet" href="event.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- NAVBAR -->
<header class="site-header">
    <div class="navbar">
    <div class="logo">🎓 College Event Portal</div>
    <div class="menu">
        <a href="../index.php">Home</a>
        <a href="index.php">Events</a>
        <a href="../gallery.php">Gallery</a>
        <a href="../login.php">Login</a>
        <a href="../register.php">Register</a>
    </div>
</div>
<style>
```css
/* =========================
   GLOBAL
========================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f7fb;
    color:#111827;
    overflow-x:hidden;
}

/* =========================
   HERO SECTION
========================= */

.page-hero{
    width:90%;
    margin:35px auto;
    padding:70px 40px;
    text-align:center;
    border-radius:30px;
    background:linear-gradient(135deg,#081229,#1d4ed8);
    color:#fff;
    box-shadow:0 20px 40px rgba(8,18,41,.15);
}

.page-hero h1{
    font-size:48px;
    font-weight:700;
    margin-bottom:12px;
}

.page-hero p{
    color:#dbeafe;
    font-size:18px;
    max-width:700px;
    margin:auto;
}

/* =========================
   FILTER BAR
========================= */

.filter-bar{
    width:90%;
    margin:30px auto;
    background:rgba(255,255,255,.95);
    backdrop-filter:blur(10px);
    padding:22px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
}

.filter-bar form{
    display:flex;
    gap:15px;
    flex-wrap:wrap;
    justify-content:center;
}

.filter-bar input,
.filter-bar select{
    padding:14px 18px;
    min-width:250px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
    font-size:15px;
    transition:.3s;
}

.filter-bar input:focus,
.filter-bar select:focus{
    border-color:#2563eb;
}

.filter-bar button{
    background:linear-gradient(
        135deg,
        #2563eb,
        #4f46e5
    );
    color:white;
    border:none;
    padding:14px 25px;
    border-radius:12px;
    cursor:pointer;
    font-weight:600;
    transition:.3s;
}

.filter-bar button:hover{
    transform:translateY(-2px);
}

/* =========================
   SECTION TITLE
========================= */

.section-title{
    width:90%;
    margin:60px auto 35px;
    text-align:center;
}

.section-title h2{
    font-size:38px;
    margin-bottom:10px;
}

.section-title p{
    color:#6b7280;
}

/* =========================
   EVENTS GRID
========================= */

.events-wrapper{
    width:90%;
    margin:auto;

    gap:35px;
}

/* =========================
   EVENT CARD
========================= */

.event-card{
    background:white;
    border-radius:25px;
    overflow:hidden;
    display:flex;
    width: 25%;
    flex-direction:column;
    box-shadow:
    0 10px 30px rgba(0,0,0,.08);
    transition:.4s;
}

.event-card:hover{
    transform:translateY(-10px);
    box-shadow:
    0 20px 40px rgba(37,99,235,.15);
}

/* IMAGE */

.event-image-wrapper{
    position:relative;
    overflow:hidden;
}

.event-image{
    width:100%;
    height:250px;
    object-fit:cover;
    display:block;
    transition:.5s;
}

.event-card:hover .event-image{
    transform:scale(1.08);
}

.event-image-wrapper::after{
    content:'';
    position:absolute;
    inset:0;
    background:
    linear-gradient(
    to top,
    rgba(0,0,0,.55),
    transparent
    );
}

/* CATEGORY */

.event-badge{
    position:absolute;
    top:15px;
    right:15px;
    z-index:10;
    background:#2563eb;
    color:white;
    padding:8px 14px;
    border-radius:50px;
    font-size:12px;
    font-weight:600;
}

/* CONTENT */

.event-content{
    padding:25px;
    display:flex;
    flex-direction:column;
    flex:1;
}

.event-content h3{
    font-size:28px;
    margin-bottom:12px;
    color:#111827;
}

.event-desc{
    color:#6b7280;
    line-height:1.8;
    margin-bottom:20px;
}

/* INFO */

.event-info{
    display:flex;
    flex-direction:column;
    gap:12px;
    margin-bottom:25px;
}

.event-info span{
    display:flex;
    align-items:center;
    gap:10px;
    color:#4b5563;
}

.event-info i{
    color:#2563eb;
}

/* BUTTONS */

.event-buttons{
    margin-top:auto;
    display:flex;
    gap:12px;
}

.view-btn,
.register-btn{
    flex:1;
    text-align:center;
    text-decoration:none;
    padding:14px;
    border-radius:12px;
    font-weight:600;
    transition:.3s;
}

.view-btn{
    background:#eef2ff;
    color:#2563eb;
}

.view-btn:hover{
    background:#dbeafe;
}

.register-btn{
    background:
    linear-gradient(
    135deg,
    #16a34a,
    #22c55e
    );
    color:white;
}

.register-btn:hover{
    transform:translateY(-2px);
}

/* =========================
   EMPTY STATE
========================= */

.empty-state{
    grid-column:1/-1;
    background:white;
    padding:80px 40px;
    border-radius:25px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
}

.empty-state i{
    font-size:70px;
    color:#cbd5e1;
    margin-bottom:20px;
}

.empty-state h3{
    font-size:32px;
    margin-bottom:10px;
}

.empty-state p{
    color:#6b7280;
}

/* =========================
   FEATURES SECTION
========================= */

.extra-section{
    width:90%;
    margin:90px auto;
    text-align:center;
}

.extra-section h2{
    font-size:38px;
    margin-bottom:40px;
}

.features{
    display:grid;
    grid-template-columns:
    repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

.feature-box{
    background:white;
    padding:35px;
    border-radius:22px;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
    transition:.3s;
}

.feature-box:hover{
    transform:translateY(-8px);
}

.feature-icon{
    font-size:45px;
    margin-bottom:15px;
}

.feature-box h3{
    margin-bottom:12px;
}

.feature-box p{
    color:#6b7280;
    line-height:1.7;
}

/* =========================
   FOOTER
========================= */

.footer{
    background:#081229;
    color:white;
    text-align:center;
    padding:25px;
    margin-top:70px;
}

/* =========================
   ANIMATION
========================= */

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(30px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

.event-card{
    animation:fadeUp .7s ease;
}

/* =========================
   MOBILE
========================= */

@media(max-width:768px){

    .page-hero{
        padding:50px 20px;
    }

    .page-hero h1{
        font-size:34px;
    }

    .events-wrapper{
        width:95%;
        grid-template-columns:1fr;
    }

    .filter-bar form{
        flex-direction:column;
    }

    .filter-bar input,
    .filter-bar select,
    .filter-bar button{
        width:100%;
    }

    .event-buttons{
        flex-direction:column;
    }

    .event-content h3{
        font-size:24px;
    }
}

</style>
</header>
<!-- PAGE HERO -->
<section class="page-hero">
    <h1>🎉 All Events</h1>
    <p>
        Discover and participate in exciting college activities.
        Total Events: <strong><?php echo $totalEvents; ?></strong>
    </p>
</section>

<!-- FILTER BAR -->
<div class="filter-bar">
    <form method="GET">

        <input
            type="text"
            name="search"
            placeholder="🔍 Search event..."
            value="<?php echo htmlspecialchars($search); ?>"
        >

        <select name="filter">
            <option value="">All Events</option>

            <option value="upcoming"
                <?php if($filter=='upcoming') echo 'selected'; ?>>
                Upcoming Events
            </option>

            <option value="past"
                <?php if($filter=='past') echo 'selected'; ?>>
                Past Events
            </option>
        </select>

        <button type="submit">
            Filter
        </button>

    </form>
</div>

<!-- EVENTS SECTION -->
<section class="events-section">

    <div class="section-title">
        <h2>🎉 Discover Upcoming Events</h2>
        <p>
            Participate in exciting college activities,
            workshops, competitions and cultural programs.
        </p>
    </div>

    <div class="events-wrapper">

    <?php if ($totalEvents > 0) { ?>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>

        <div class="event-card">

            <!-- EVENT IMAGE -->

            <div class="event-image-box">

                <img
                src="../uploads/<?=
                !empty($row['event_image'])
                ? $row['event_image']
                : 'default-event.jpg'
                ?>"
                alt="<?= htmlspecialchars($row['event_name']) ?>"
                class="event-image">

                <?php if(!empty($row['event_category'])){ ?>

                    <span class="event-badge">
                        <?= htmlspecialchars($row['event_category']) ?>
                    </span>

                <?php } ?>

            </div>

            <!-- EVENT CONTENT -->

            <div class="event-content">

                <h3>
                    <?= htmlspecialchars($row['event_name']) ?>
                </h3>

                <p class="event-desc">

                    <?=
                    !empty($row['event_description'])
                    ? substr(
                        htmlspecialchars(
                        $row['event_description']),
                        0,
                        120
                    )."..."
                    : "Join this exciting event and enhance your skills while connecting with students."
                    ?>

                </p>

                <div class="event-info">

                    <span>
                        📅
                        <?= date(
                        "d M Y",
                        strtotime(
                        $row['event_date']
                        )) ?>
                    </span>

                    <?php if(!empty($row['event_location'])){ ?>

                    <span>
                        📍
                        <?= htmlspecialchars(
                        $row['event_location']
                        ) ?>
                    </span>

                    <?php } ?>

                </div>

                <div class="event-buttons">

                    <a
                    href="view_event.php?id=<?= $row['id'] ?>"
                    class="view-btn">

                        View Details

                    </a>

                    <a
                    href="register_event.php?event_id=<?= $row['id'] ?>"
                    class="register-btn">

                        Register

                    </a>

                </div>

            </div>

        </div>

        <?php } ?>

    <?php } else { ?>

        <div class="empty-state">

            <div class="empty-icon">
                📅
            </div>

            <h3>No Events Available</h3>

            <p>
                No events match your search.
                Please try another filter.
            </p>

        </div>

    <?php } ?>

    </div>

</section>
```

<!-- EXTRA FEATURES -->
<section class="extra-section">

    <h2>Why Join Our Events?</h2>

    <div class="features">

        <div class="feature-box">
            <div class="feature-icon">🎯</div>
            <h3>Skill Building</h3>
            <p>
                Improve your technical and soft skills through workshops,
                seminars and competitions.
            </p>
        </div>

        <div class="feature-box">
            <div class="feature-icon">🤝</div>
            <h3>Networking</h3>
            <p>
                Meet students, faculty members and industry experts to
                expand your professional network.
            </p>
        </div>

        <div class="feature-box">
            <div class="feature-icon">🏆</div>
            <h3>Achievements</h3>
            <p>
                Earn certificates, prizes and recognition that strengthen
                your portfolio and resume.
            </p>
        </div>

    </div>

</section>
<!-- FOOTER -->
<div class="footer">
    © 2026 College Event Management System
</div>
</body>
</html>
