<?php
include "../db_connect.php";

if (!isset($_GET['id'])) {
    die("Event not found");
}

$event_id = intval($_GET['id']);

// Fetch event details
$event_sql = "SELECT * FROM events WHERE id = $event_id";
$event_result = mysqli_query($conn, $event_sql);
$event = mysqli_fetch_assoc($event_result);

if (!$event) {
    die("Invalid Event");
}

// Handle form submit
if (isset($_POST['register'])) {
    $name  = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $roll  = mysqli_real_escape_string($conn, $_POST['roll']);

    $insert = "INSERT INTO event_registrations 
        (event_id, student_name, student_email, student_class, student_roll)
        VALUES ('$event_id','$name','$email','$class','$roll')";

    if (mysqli_query($conn, $insert)) {
        $success = true;
    } else {
        $error = "Registration failed!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register for <?php echo $event['event_name']; ?></title>
    <style>
        body {
            font-family: Arial;
            background: #f4f6f8;
        }
        .container {
            width: 420px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .success {
            color: green;
            text-align: center;
            margin-bottom: 10px;
        }
        .back {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2><?php echo $event['event_name']; ?></h2>
    <p><b>Date:</b> <?php echo $event['event_date']; ?></p>

    <?php if (isset($success)) { ?>
        <p class="success">✅ Registration Successful!</p>
    <?php } ?>

    <form method="post">
        <input type="text" name="name" placeholder="Student Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="class" placeholder="Class">
        <input type="text" name="roll" placeholder="Roll Number">
        <button type="submit" name="register">Register</button>
    </form>

    <div class="back">
        <a href="index.php">⬅ Back to Events</a>
    </div>
</div>

</body>
</html>
