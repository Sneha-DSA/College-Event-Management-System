<?php
include("../db_connect.php");

if (!isset($_GET['id'])) {
    die("Event not found");
}

$event_id = intval($_GET['id']);

$eventQuery = "SELECT event_name FROM events WHERE id = $event_id";
$eventResult = mysqli_query($conn, $eventQuery);
$event = mysqli_fetch_assoc($eventResult);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];

    $insert = "INSERT INTO event_registrations 
               (event_id, student_name, student_email, student_mobile)
               VALUES ('$event_id', '$name', '$email', '$mobile')";

    if (mysqli_query($conn, $insert)) {
        echo "<script>alert('Registration Successful!'); window.location='index.php';</script>";
    } else {
        echo "Error!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - <?php echo $event['event_name']; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(120deg, #dff9fb, #ffffff);
        }
        .form-box {
            max-width: 450px;
            margin: 80px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #130f40;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 12px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #1e90ff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0b5ed7;
        }
    </style>
</head>

<body>

<div class="form-box">
    <h2>Register for<br><?php echo $event['event_name']; ?></h2>

    <form method="POST">
        <input type="text" name="name" placeholder="Student Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="mobile" placeholder="Mobile Number" required>
        <button type="submit">Submit Registration</button>
    </form>
</div>

</body>
</html>
