<?php
include "../db_connect.php";

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No event selected.");
}

$id = (int) $_GET['id'];

$query = "SELECT * FROM events WHERE id = $id LIMIT 1";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    die("Event not found.");
}

$event = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($event['event_name']); ?> | Event Details</title>
   <link rel="stylesheet" href="event.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>/* ===== EVENT HERO ===== */
.page-hero {
    position: relative;
    text-align: center;
    padding: 90px 20px 70px;
    background: linear-gradient(135deg, #4f46e5, #6366f1);
    color: white;
    overflow: hidden;
}

/* subtle glow */
.page-hero::after {
    content: "";
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at top, rgba(255,255,255,0.25), transparent 60%);
    pointer-events: none;
}

.page-hero h1 {
    font-size: 44px;
    font-weight: 700;
    margin-bottom: 12px;
    letter-spacing: -0.4px;
}

.page-hero p {
    font-size: 16px;
    opacity: 0.95;
}

/* ===== EVENT DETAILS WRAPPER ===== */
.event-details-wrapper {
    display: flex;
    justify-content: center;
    padding: 60px 20px 100px;
    background: linear-gradient(to bottom, #eef2ff, #f8fafc);
}

/* ===== EVENT DETAILS CARD ===== */
.event-details-card {
    max-width: 720px;
    width: 100%;
    background: rgba(255, 255, 255, 0.88);
    backdrop-filter: blur(14px);
    border-radius: 22px;
    padding: 45px;
    box-shadow:
        0 30px 60px rgba(0,0,0,0.15),
        inset 0 1px 0 rgba(255,255,255,0.6);
    animation: eventFadeUp 0.6s ease;
}

/* smooth entrance */
@keyframes eventFadeUp {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.event-details-card h2 {
    font-size: 26px;
    margin-bottom: 16px;
    color: #111827;
}

/* DESCRIPTION */
.event-description {
    font-size: 16px;
    line-height: 1.85;
    color: #374151;
    margin-bottom: 35px;
}

/* ===== ACTIONS ===== */
.event-actions {
    display: flex;
    justify-content: flex-end;
}

.btn-outline {
    padding: 12px 28px;
    border-radius: 30px;
    border: 2px solid #4f46e5;
    color: #4f46e5;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.btn-outline:hover {
    background: #4f46e5;
    color: white;
    box-shadow: 0 12px 28px rgba(79,70,229,0.35);
    transform: translateY(-2px);
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
    .page-hero h1 {
        font-size: 32px;
    }

    .event-details-card {
        padding: 30px;
    }
}
/* ===== EVENT ACTION BUTTONS ===== */
.event-actions {
    display: flex;
    justify-content: flex-end;
    gap: 18px;
    flex-wrap: wrap;
}

/* PRIMARY CTA */
.btn-primary {
    padding: 13px 32px;
    border-radius: 30px;
    background: linear-gradient(135deg, #22c55e, #16a34a);
    color: white;
    font-weight: 600;
    font-size: 15px;
    text-decoration: none;
    box-shadow: 0 10px 25px rgba(34,197,94,0.35);
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 15px 35px rgba(34,197,94,0.45);
    background: linear-gradient(135deg, #16a34a, #15803d);
}

/* OUTLINE (BACK) */
.btn-outline {
    padding: 12px 28px;
    border-radius: 30px;
    border: 2px solid #4f46e5;
    color: #4f46e5;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.btn-outline:hover {
    background: #4f46e5;
    color: white;
    box-shadow: 0 12px 28px rgba(79,70,229,0.35);
    transform: translateY(-2px);
}

/* MOBILE FRIENDLY */
@media (max-width: 480px) {
    .event-actions {
        justify-content: center;
    }
}

</style>
</head>
<body>

<!-- HEADER -->
<header class="site-header">
    <div class="navbar">
    <div class="logo">🎓 College Event Portal</div>
    <div class="menu">
        <a href="../index.php">Home</a>
        <a href="index.php">Events</a>
        <a href="gallery.php">Gallery</a>
        <a href="event/add_event.php">Add Event</a>
        <a href="../login.php">Login</a>
        <a href="../register.php">Register</a>
    
    </div>
</header>

<!-- EVENT HERO -->
<section class="page-hero">
    <h1><?php echo htmlspecialchars($event['event_name']); ?></h1>
    <p>
        📅 
        <?php 
        echo !empty($event['event_date']) 
            ? date("d M Y", strtotime($event['event_date'])) 
            : "Date not announced";
        ?>
    </p>
</section>

<!-- EVENT DETAILS -->

<section class="event-details-section">

    <div class="event-container">

        <!-- LEFT -->

        <div class="event-image-box">

            <img
            src="../uploads/<?=
            !empty($event['event_image'])
            ? $event['event_image']
            : 'default-event.jpg'
            ?>"
            alt="<?= htmlspecialchars($event['event_name']) ?>">

            <span class="event-category">
                <?= htmlspecialchars($event['event_category']) ?>
            </span>

        </div>

        <!-- RIGHT -->

        <div class="event-info-box">

            <h2>
                <?= htmlspecialchars($event['event_name']) ?>
            </h2>

            <p class="event-description">

                <?= nl2br(
                    htmlspecialchars(
                        $event['event_description']
                    )
                ) ?>

            </p>

            <div class="info-grid">

                <div class="info-item">

                    📅

                    <div>

                        <strong>Date</strong>

                        <p>
                            <?= date(
                                "d M Y",
                                strtotime(
                                    $event['event_date']
                                )
                            ) ?>
                        </p>

                    </div>

                </div>

                <div class="info-item">

                    📍

                    <div>

                        <strong>Location</strong>

                        <p>
                            <?= htmlspecialchars(
                                $event['event_location']
                            ) ?>
                        </p>

                    </div>

                </div>

                <div class="info-item">

                    🎯

                    <div>

                        <strong>Category</strong>

                        <p>
                            <?= htmlspecialchars(
                                $event['event_category']
                            ) ?>
                        </p>

                    </div>

                </div>

            </div>

            <div class="event-actions">

                <a
                href="../login.php"
                class="btn-primary">

                    🚀 Register Now

                </a>

                <a
                href="index.php"
                class="btn-outline">

                    ← Back

                </a>

            </div>

        </div>

    </div>

</section>
<style>
    
/* =======================
EVENT DETAILS SECTION
======================= */

.event-details-section{
    padding:80px 0;
    background:#f4f7fb;
}

.event-container{
    width:90%;
    max-width:1300px;
    margin:auto;

    display:grid;
    grid-template-columns:1fr 1fr;
    gap:50px;
    align-items:center;
}

/* IMAGE */

.event-image-box{
    position:relative;
}

.event-image-box img{
    width:100%;
    height:500px;
    object-fit:cover;
    border-radius:25px;

    box-shadow:
    0 20px 50px rgba(0,0,0,.15);
}

.event-category{
    position:absolute;
    top:20px;
    right:20px;

    background:#2563eb;
    color:white;

    padding:10px 18px;

    border-radius:50px;

    font-size:13px;
    font-weight:600;
}

/* CONTENT */

.event-info-box{
    background:white;
    padding:40px;
    border-radius:25px;

    box-shadow:
    0 15px 40px rgba(0,0,0,.08);
}

.event-info-box h2{
    font-size:42px;
    margin-bottom:20px;
    color:#081229;
}

.event-description{
    color:#6b7280;
    line-height:1.9;
    margin-bottom:35px;
    font-size:16px;
}

/* INFO GRID */

.info-grid{
    display:grid;
    gap:18px;
    margin-bottom:35px;
}

.info-item{
    display:flex;
    gap:15px;
    align-items:center;

    padding:18px;

    background:#f8fafc;

    border-radius:15px;
}

.info-item strong{
    display:block;
    color:#081229;
}

.info-item p{
    margin-top:3px;
    color:#6b7280;
}

/* BUTTONS */

.event-actions{
    display:flex;
    gap:15px;
}

.btn-primary{
    flex:1;
    text-align:center;

    text-decoration:none;

    background:
    linear-gradient(
    135deg,
    #16a34a,
    #22c55e
    );

    color:white;

    padding:15px;
    border-radius:12px;

    font-weight:600;
}

.btn-primary:hover{
    transform:translateY(-3px);
}

.btn-outline{
    flex:1;
    text-align:center;

    text-decoration:none;

    border:2px solid #2563eb;

    color:#2563eb;

    padding:15px;

    border-radius:12px;

    font-weight:600;
}

.btn-outline:hover{
    background:#2563eb;
    color:white;
}

/* MOBILE */

@media(max-width:900px){

    .event-container{
        grid-template-columns:1fr;
    }

    .event-image-box img{
        height:300px;
    }

    .event-info-box h2{
        font-size:30px;
    }

    .event-actions{
        flex-direction:column;
    }
}
```

</style>


    </div>
</div>

<!-- FOOTER -->
<footer class="footer">
    <p>© College Event Portal · Academic Use Only</p>
</footer>

</body>
</html>
