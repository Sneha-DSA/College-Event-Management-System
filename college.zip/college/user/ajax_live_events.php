<?php
session_start();
require "../db_connect.php";

$query = "SELECT * FROM events WHERE status='live' ORDER BY event_date ASC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("SQL ERROR: " . mysqli_error($conn));
}
?>
<style>
.live-events-title {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: 30px;
    color: #111827;
}

.live-events-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    gap: 30px;
}

.event-card {
    background: #ffffff;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
    border-left: 6px solid #4f46e5;
    transition: 0.3s ease;
}

.event-card:hover {
    transform: translateY(-8px);
}

.event-card h3 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #111827;
}

.event-card p {
    font-size: 15px;
    line-height: 1.7;
    color: #374151;
    margin-bottom: 10px;
}

.event-description {
    margin: 15px 0;
    color: #4b5563;
}

.register-btn{

background:linear-gradient(135deg,#2563eb,#4f46e5);

color:white;

border:none;

padding:12px 20px;

border-radius:10px;

cursor:pointer;

font-weight:600;

margin-top:15px;

}

.no-events {
    background: white;
    padding: 30px;
    border-radius: 20px;
    text-align: center;
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .live-events-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<h2 class="live-events-title">📅 Live Events</h2>

<?php if (mysqli_num_rows($result) == 0): ?>

    <div class="no-events">
        <p>No live events currently.</p>
    </div>

<?php else: ?>

    <div class="live-events-grid">

        <?php while ($event = mysqli_fetch_assoc($result)): ?>

            <div class="event-card">

                <h3><?= htmlspecialchars($event['event_name']) ?></h3>

                <p class="event-description">
                    <?= !empty($event['event_details'])
                        ? nl2br(htmlspecialchars($event['event_details']))
                        : "Details will be updated soon."; ?>
                </p>

                <p><strong>📅 Date:</strong> <?= htmlspecialchars($event['event_date']) ?></p>

                <p><strong>💰 Price:</strong> ₹<?= htmlspecialchars($event['price']) ?></p>
<button onclick="registerEvent(<?= $row['id'] ?>)"
class="register-btn">

Register Now

</button>
            </div>

        <?php endwhile; ?>

    </div>

<?php endif; ?>