<?php

session_start();
require "../db_connect.php";

/* CHECK LOGIN */

if(!isset($_SESSION['user_id'])){

    echo "

    <div class='pay-box'>

        <h2>Please Login Again</h2>

    </div>

    ";

    exit();
}

/* EVENT ID */

$event_id = (int)($_POST['event_id'] ?? 0);

/* MEMBERS */

$members = (int)($_POST['members'] ?? 1);

if($event_id <= 0){

    echo "

    <div class='pay-box'>

        <h2>Invalid Event</h2>

    </div>

    ";

    exit();
}

/* FETCH EVENT */

$query = mysqli_query($conn,

"SELECT * FROM events
WHERE id='$event_id'"

);

if(!$query){

    die(mysqli_error($conn));

}

if(mysqli_num_rows($query) == 0){

    echo "

    <div class='pay-box'>

        <h2>Event Not Found</h2>

    </div>

    ";

    exit();
}

$event = mysqli_fetch_assoc($query);

/* PRICE */

$price = (int)($event['price'] ?? 500);

$total_amount = $price * $members;

?>

<style>

.pay-box{

    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    max-width:700px;
    margin:auto;
    animation:fadeIn 0.4s ease;
}

@keyframes fadeIn{

    from{
        opacity:0;
        transform:translateY(20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

.pay-box h2{

    font-size:32px;
    margin-bottom:20px;
    color:#111827;
}

.pay-info{

    background:#f3f4f6;
    padding:20px;
    border-radius:15px;
    margin-bottom:25px;
}

.pay-info p{

    margin:12px 0;
    color:#374151;
    font-size:16px;
}

.form-group{

    margin-bottom:20px;
}

.form-group label{

    display:block;
    margin-bottom:8px;
    font-weight:600;
    color:#374151;
}

.form-group input{

    width:100%;
    padding:15px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
    font-size:15px;
}

.form-group input:focus{

    border-color:#4f8cff;
}

.pay-btn{

    width:100%;
    border:none;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    padding:16px;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

.pay-btn:hover{

    transform:translateY(-3px);
}

.success-box{

    background:white;
    padding:40px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    max-width:700px;
    margin:auto;
    text-align:center;
}

.success-box h2{

    color:#16a34a;
    font-size:34px;
    margin-bottom:20px;
}

.success-box p{

    font-size:17px;
    color:#555;
    line-height:1.8;
}

</style>

<div class="pay-box">

    <h2>
        💳 Payment Preview
    </h2>

    <div class="pay-info">

        <p>

            <strong>Event:</strong>

            <?= htmlspecialchars($event['event_name']) ?>

        </p>

        <p>

            <strong>Members:</strong>

            <?= $members ?>

        </p>

        <p>

            <strong>Price Per Member:</strong>

            ₹<?= $price ?>

        </p>

        <p style="font-size:22px;
        color:#16a34a;
        font-weight:700;">

            Total Amount:
            ₹<?= $total_amount ?>

        </p>

    </div>

    <form id="confirmBookingForm">

        <input type="hidden"
        name="event_id"
        value="<?= $event_id ?>">

        <input type="hidden"
        name="members"
        value="<?= $members ?>">

        <input type="hidden"
        name="amount"
        value="<?= $total_amount ?>">

        <div class="form-group">

            <label>
                Mobile Number
            </label>

            <input type="text"
            name="mobile"
            placeholder="Enter Mobile Number"
            required>

        </div>

        <div class="form-group">

            <label>
                Coupon Code
            </label>

            <input type="text"
            name="coupon_code"
            placeholder="Enter Coupon Code">

        </div>

        <button type="submit"
        class="pay-btn">

            Confirm & Pay ₹<?= $total_amount ?>

        </button>

    </form>

</div>

<script>

document.getElementById("confirmBookingForm")

.addEventListener("submit", function(e){

    e.preventDefault();

    let formData = new FormData(this);

    fetch("./confirm_booking.php",{

        method:"POST",

        body:formData

    })

    .then(response => response.text())

    .then(data => {

        document.getElementById("liveEventsContainer")
        .innerHTML = data;

        document.getElementById("liveEventsContainer")
        .scrollIntoView({
            behavior:"smooth"
        });

    })

    .catch(error => {

        console.log(error);

        alert("Payment Failed");

    });

});

</script>