<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


session_start();
require "../db_connect.php";

/* CHECK LOGIN */

if (!isset($_SESSION['user_id'])) {

    echo "
    <div class='error-box'>
        Please Login Again
    </div>
    ";

    exit();
}

/* USER */

$user_id = $_SESSION['user_id'];

/* EVENT ID */

$event_id = (int)($_GET['event_id'] ?? 0);

if ($event_id <= 0) {

    echo "
    <div class='error-box'>
        Invalid Event
    </div>
    ";

    exit();
}

/* FETCH EVENT */

$eventQuery = mysqli_query(
    $conn,
    "SELECT * FROM events WHERE id='$event_id'"
);

if (!$eventQuery) {
    die(mysqli_error($conn));
}

if (mysqli_num_rows($eventQuery) == 0) {

    echo "
    <div class='error-box'>
        Event Not Found
    </div>
    ";

    exit();
}

$event = mysqli_fetch_assoc($eventQuery);

/* FETCH USER */

$userQuery = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE id='$user_id'"
);

$user = mysqli_fetch_assoc($userQuery);

/* FORM SUBMIT */

/* FORM SUBMIT */

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'])
    );

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        trim($_POST['mobile'])
    );

    $members = (int)($_POST['members'] ?? 1);

    $registration_code = mysqli_real_escape_string(
        $conn,
        trim($_POST['coupon'])
    );

    /* VALIDATION */

    if (empty($mobile)) {

        echo "
        <div class='error-box'>
            Mobile Number Required
        </div>";
        exit();
    }

    if (empty($registration_code)) {

        echo "
        <div class='error-box'>
            Registration Code Required
        </div>";
        exit();
    }

    /* CHECK DUPLICATE */

    $check = mysqli_query(
        $conn,
        "SELECT id
         FROM event_registrations
         WHERE student_email='$email'
         AND event_id='$event_id'"
    );

    if (mysqli_num_rows($check) > 0) {

        echo "
        <div class='success-box'>
            <h2>🎉 Already Registered</h2>
            <p>You have already registered for this event.</p>
        </div>";
        exit();
    }

    /* INSERT REGISTRATION */

    $insert = mysqli_query(
        $conn,
        "INSERT INTO event_registrations
        (
            event_id,
            student_name,
            student_email,
            student_mobile,
            members,
            registration_code
        )
        VALUES
        (
            '$event_id',
            '$name',
            '$email',
            '$mobile',
            '$members',
            '$registration_code'
        )"
    );

    if (!$insert) {
        die(mysqli_error($conn));
    }

    echo "

    <div class='success-box'>

        <h2>🎉 Registration Successful</h2>

        <p>

            <strong>Event:</strong>
            {$event['event_name']}

            <br><br>

            <strong>Name:</strong>
            {$name}

            <br><br>

            <strong>Email:</strong>
            {$email}

            <br><br>

            <strong>Mobile:</strong>
            {$mobile}

            <br><br>

            <strong>Members:</strong>
            {$members}

            <br><br>

            <strong>Registration Code:</strong>
            {$registration_code}

        </p>

    </div>

    ";

    exit();
}
?>

<style>

.register-card{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    max-width:700px;
    margin:auto;
}

.register-card h2{
    font-size:32px;
    margin-bottom:20px;
    color:#111827;
}

.event-info{
    background:#f3f4f6;
    padding:20px;
    border-radius:15px;
    margin-bottom:25px;
}

.event-info p{
    margin:10px 0;
    color:#374151;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input{
    width:100%;
    padding:14px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
}

.form-group input:focus{
    border-color:#2563eb;
}

.register-btn{
    width:100%;
    border:none;
    background:linear-gradient(135deg,#2563eb,#4f46e5);
    color:white;
    padding:16px;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
}

.success-box{
    background:white;
    padding:40px;
    border-radius:25px;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    max-width:700px;
    margin:auto;
}

.success-box h2{
    color:#16a34a;
    margin-bottom:20px;
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:25px;
    border-radius:15px;
    text-align:center;
    max-width:600px;
    margin:auto;
}

</style>

<div class="register-card">

    <h2>📝 Register Event</h2>

    <div class="event-info">

        <p>
            <strong>Event:</strong>
            <?= htmlspecialchars($event['event_name']) ?>
        </p>

        <p>
            <strong>Date:</strong>
            <?= htmlspecialchars($event['event_date']) ?>
        </p>

    </div>

    <form id="registerForm">

        <div class="form-group">
            <label>Full Name</label>

            <input
                type="text"
                name="name"
                value="<?= htmlspecialchars($user['full_name']) ?>"
                readonly>
        </div>

        <div class="form-group">
            <label>Email</label>

            <input
                type="email"
                name="email"
                value="<?= htmlspecialchars($user['email']) ?>"
                readonly>
        </div>

        <div class="form-group">
            <label>Mobile Number</label>

            <input
                type="text"
                name="mobile"
                required>
        </div>

        <div class="form-group">
            <label>Number Of Members</label>

            <input
                type="number"
                name="members"
                min="1"
                value="1"
                required>
        </div>

        <div class="form-group">
            <label>Registration Code</label>

            <input
                type="text"
                name="coupon"
                placeholder="Enter Registration Code"
                required>
        </div>

        <button
            type="submit"
            class="register-btn">
            Register Now
        </button>

    </form>

</div>

<script>

document.getElementById("registerForm")

.addEventListener("submit", function(e){

    e.preventDefault();

    let formData = new FormData(this);

    fetch("./ajax_register_event.php?event_id=<?= $event_id ?>",{

        method:"POST",
        body:formData

    })

    .then(response => response.text())

    .then(data => {

        document.getElementById("liveEventsContainer")
        .innerHTML = data;

        document.getElementById("liveEventsContainer")
        .scrollIntoView({
            behavior:"smooth"
        });

    })

    .catch(error => {

        console.log(error);

        alert("Something went wrong");

    });

});

</script>
```
