<?php

session_start();
require "../db_connect.php";

if(!isset($_SESSION['user_id'])){

    exit("Login Required");

}

$event_id = $_POST['event_id'];

$members = $_POST['members'];

$mobile = $_POST['mobile'];

$amount = $_POST['amount'];

$user_id = $_SESSION['user_id'];

/* USER */

$userQuery = mysqli_query($conn,

"SELECT * FROM users
WHERE id='$user_id'"

);

$user = mysqli_fetch_assoc($userQuery);

/* EVENT */

$eventQuery = mysqli_query($conn,

"SELECT * FROM events
WHERE id='$event_id'"

);

$event = mysqli_fetch_assoc($eventQuery);

/* INSERT */

$insert = mysqli_query($conn,

"INSERT INTO event_registrations

(event_id,
student_name,
student_email,
student_mobile,
members)

VALUES

('$event_id',
'".$user['full_name']."',
'".$user['email']."',
'$mobile',
'$members')"

);

if(!$insert){

    die(mysqli_error($conn));

}

?>

<style>

.success-box{

    background:white;
    padding:40px;
    border-radius:25px;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    max-width:700px;
    margin:auto;
    text-align:center;
}

.success-box h2{

    color:#16a34a;
    font-size:36px;
    margin-bottom:20px;
}

.success-box p{

    font-size:17px;
    color:#555;
    line-height:1.8;
}

.home-btn{

    display:inline-block;
    margin-top:25px;
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:14px 25px;
    border-radius:12px;
    font-weight:600;
}

</style>

<div class="success-box">

    <h2>
        🎉 Payment Successful
    </h2>

    <p>

        Your booking has been confirmed.

        <br><br>

        <strong>Event:</strong>
        <?= htmlspecialchars($event['event_name']) ?>

        <br><br>

        <strong>Members:</strong>
        <?= $members ?>

        <br><br>

        <strong>Total Paid:</strong>
        ₹<?= $amount ?>

    </p>

    <a href="dashboard.php"
    class="home-btn">

        Back To Dashboard

    </a>

</div>