
<?php
session_start();

include "../db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$username = $_SESSION['user_name'] ?? 'Student';
$userId   = $_SESSION['user_id'];

/* TOTAL LIVE EVENTS */

$eventCount = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total FROM events"
    )
)['total'];

/* REGISTERED EVENTS */

$registeredCount = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM event_registrations
         WHERE user_id = '$userId'"
    )
)['total'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Dashboard</title>

    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        }

        body{
            background:#f4f7fb;
            color:#111827;
        }

        /* NAVBAR */

        .navbar{
            width:100%;
            background:#081229;
            padding:18px 8%;
            display:flex;
            justify-content:space-between;
            align-items:center;
            position:sticky;
            top:0;
            z-index:1000;
            box-shadow:0 5px 20px rgba(0,0,0,0.15);
        }

        .logo{
            color:white;
            font-size:24px;
            font-weight:700;
        }

        .logo span{
            color:#4f8cff;
        }

        .menu{
            display:flex;
            align-items:center;
            gap:25px;
        }

        .menu a{
            text-decoration:none;
            color:white;
            font-size:15px;
            transition:0.3s;
        }

        .menu a:hover{
            color:#4f8cff;
        }

        .logout-btn{
            background:#ff4d4d;
            padding:10px 18px;
            border-radius:8px;
        }

        /* HERO */



        .secondary-btn{
    display:inline-block;
    background:white;
    color:#081229;
    padding:14px 22px;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    text-decoration:none;
    transition:0.3s;
}

.secondary-btn:hover{
    transform:translateY(-3px);
}

        .hero{
            width:90%;
            margin:40px auto;
            background:linear-gradient(135deg,#081229,#163c78);
            border-radius:25px;
            padding:50px;
            color:white;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
        }

        .hero-text h1{
            font-size:42px;
            margin-bottom:10px;
        }

        .hero-text p{
            color:#dbe4ff;
            font-size:17px;
        }

        .hero-buttons{
            margin-top:20px;
        }

        .hero-buttons button{
            border:none;
            padding:14px 22px;
            border-radius:10px;
            font-size:15px;
            font-weight:600;
            cursor:pointer;
            margin-right:15px;
            transition:0.3s;
        }

        .primary-btn{
            background:#4f8cff;
            color:white;
        }

        .secondary-btn{
            background:white;
            color:#081229;
        }

        .hero-buttons button:hover{
            transform:translateY(-3px);
        }

        /* STATS */

        .stats{
            width:90%;
            margin:auto;
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
            gap:25px;
        }

        .stat-card{
            background:white;
            border-radius:20px;
            padding:30px;
            box-shadow:0 10px 25px rgba(0,0,0,0.08);
            display:flex;
            align-items:center;
            gap:20px;
            transition:0.3s;
            cursor:pointer;
        }

        .stat-card:hover{
            transform:translateY(-8px);
        }

        .icon-box{
            width:70px;
            height:70px;
            border-radius:18px;
            display:flex;
            justify-content:center;
            align-items:center;
            font-size:28px;
            color:white;
        }

        .blue{
            background:#4f8cff;
        }

        .green{
            background:#10b981;
        }

        .orange{
            background:#f59e0b;
        }

        .stat-info h2{
            font-size:28px;
            margin-bottom:5px;
        }

        .stat-info p{
            color:#6b7280;
        }

        /* SECTION */

        .section-title{
            width:90%;
            margin:60px auto 25px;
        }

        .section-title h2{
            font-size:32px;
        }

        /* EVENTS */

        .events-container{
            width:90%;
            margin:auto;
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
            gap:30px;
            margin-bottom:60px;
        }

        .event-card{
            background:white;
            border-radius:22px;
            overflow:hidden;
            box-shadow:0 10px 25px rgba(0,0,0,0.08);
            transition:0.3s;
        }

        .event-card:hover{
            transform:translateY(-8px);
        }

        .event-image{
            width:100%;
            height:220px;
            object-fit:cover;
        }

        .event-content{
            padding:25px;
        }

        .event-content h3{
            font-size:24px;
            margin-bottom:12px;
        }

        .event-content p{
            color:#6b7280;
            line-height:1.7;
            margin-bottom:18px;
        }

        .event-info{
            display:flex;
            flex-direction:column;
            gap:10px;
            margin-bottom:20px;
            color:#374151;
        }

        .event-info i{
            color:#4f8cff;
            margin-right:8px;
        }

        .register-btn{
            width:100%;
            border:none;
            background:#16a34a;
            color:white;
            padding:14px;
            border-radius:10px;
            cursor:pointer;
            font-size:15px;
            font-weight:600;
            transition:0.3s;
        }

        .register-btn:hover{
            background:#15803d;
        }

        /* FOOTER */

        .footer{
            background:#081229;
            color:white;
            text-align:center;
            padding:22px;
            margin-top:50px;
        }

        /* MOBILE */

        @media(max-width:768px){

            .navbar{
                flex-direction:column;
                gap:15px;
                padding:20px;
            }

            .menu{
                flex-wrap:wrap;
                justify-content:center;
            }

            .hero{
                padding:35px;
            }

            .hero-text h1{
                font-size:32px;
            }

            .hero-buttons{
                margin-top:25px;
            }

            .hero-buttons button{
                margin-bottom:12px;
            }
        }

    </style>

</head>

<body>

    <!-- NAVBAR -->

    <div class="navbar">

        <div class="logo">
            <div class="logo">🎓 College Event Portal</div>
        </div>

        <div class="menu">

            <a href="dashboard.php">Dashboard</a>

            <a href="../profile.php">Profile</a>

            <a href="my_events.php">My Bookings</a>

            <a href="../change_password.php">Password</a>

            <a href="../logout.php" class="logout-btn">
                Logout
            </a>

        </div>

    </div>

    <!-- HERO -->

   

       <div class="hero">

<div class="hero-text">

    <h1>
        Welcome Back,
        <?= htmlspecialchars($username) ?> 👋
    </h1>

    <p>
        Explore college events, register instantly and manage your activities easily.
    </p>

</div>

<div class="hero-buttons">

    <button
        class="primary-btn"
        onclick="document.getElementById('eventsSection').scrollIntoView({behavior:'smooth'})">

        Explore Events

    </button>

    <a href="my_events.php" class="secondary-btn">
        My Bookings
    </a>

</div>


</div>


    <!-- STATS -->

    <div class="stats">

        <!-- LIVE EVENTS -->

        <div class="stat-card"
onclick="document.getElementById('eventsSection').scrollIntoView({behavior:'smooth'})">

    <div class="icon-box blue">
        <i class="fa-solid fa-calendar-days"></i>
    </div>

    <div class="stat-info">
        <h2><?= $eventCount ?></h2>
        <p>Live Events</p>
    </div>

</div>

        <!-- REGISTERED -->

        <div class="stat-card"
onclick="window.location.href='my_events.php'">

    <div class="icon-box green">
        <i class="fa-solid fa-ticket"></i>
    </div>

    <div class="stat-info">
        <h2><?= $registeredCount ?></h2>
        <p>Registered Events</p>
    </div>

</div>

        <!-- PROFILE -->

        <div class="stat-card"
        onclick="window.location.href='../profile.php'">

            <div class="icon-box orange">
                <i class="fa-solid fa-user"></i>
            </div>

            <div class="stat-info">
                <h2>Profile</h2>
                <p>Manage Account</p>
            </div>

        </div>

    </div>

    <?php

$events = mysqli_query(
    $conn,
    "SELECT * FROM events
     ORDER BY event_date ASC"
);

?>

<!-- EVENTS -->

<div class="section-title" id="eventsSection">
    <h2>🔥 Upcoming Events</h2>
</div>

<div class="events-container">

<?php if(mysqli_num_rows($events) > 0){ ?>

<?php while($event = mysqli_fetch_assoc($events)){ ?>

    <div class="event-card">

        <!-- IMAGE -->

        <img
        src="../uploads/<?=
        !empty($event['event_image'])
        ? $event['event_image']
        : 'default-event.jpg'
        ?>"
        class="event-image"
        alt="<?= htmlspecialchars($event['event_name']) ?>">

        <div class="event-content">

            <h3>
                <?= htmlspecialchars($event['event_name']) ?>
            </h3>

            <p>

                <?= !empty($event['event_description'])
                ? substr(
                    htmlspecialchars(
                        $event['event_description']
                    ),
                    0,
                    100
                )."..."
                : "Join this exciting event and connect with fellow students." ?>

            </p>

            <div class="event-info">

                <span>
                    <i class="fa-solid fa-calendar"></i>

                    <?= date(
                        "d M Y",
                        strtotime(
                            $event['event_date']
                        )
                    ) ?>
                </span>

                <?php if(!empty($event['event_location'])){ ?>

                <span>
                    <i class="fa-solid fa-location-dot"></i>

                    <?= htmlspecialchars(
                        $event['event_location']
                    ) ?>
                </span>

                <?php } ?>

                <?php if(!empty($event['event_category'])){ ?>

                <span>
                    <i class="fa-solid fa-tag"></i>

                    <?= htmlspecialchars(
                        $event['event_category']
                    ) ?>
                </span>

                <?php } ?>

            </div>

            <div class="event-buttons">

                <a
                href="../event/view_event.php?id=<?= $event['id'] ?>"
                class="view-btn">

                    View Details

                </a>

                <a
href="register_event.php?event_id=<?= $event['id'] ?>"
class="register-btn">

Register

</a>

            </div>

        </div>

    </div>

<?php } ?>

<?php } else { ?>

    <div class="empty-state">

        <i class="fa-solid fa-calendar-xmark"></i>

        <h3>No Events Available</h3>

        <p>
            New events will appear here soon.
        </p>

    </div>

<?php } ?>

</div>

<div id="liveEventsContainer"
style="
width:90%;
margin:auto;
margin-top:40px;
margin-bottom:50px;
">
</div>
    <!-- FOOTER -->

    <div class="footer">
        © 2026 College Event Management System
    </div>

    <!-- JAVASCRIPT -->
<script>

function registerEvent(eventId){

    fetch("./ajax_register_event.php?event_id=" + eventId)

    .then(response => response.text())

    .then(data => {

        document.getElementById("liveEventsContainer")
        .innerHTML = data;

        document.getElementById("liveEventsContainer")
        .scrollIntoView({
            behavior:"smooth"
        });

    })

    .catch(error => {

        console.log(error);

        alert("Something went wrong");

    });

}

</script>
<style>
.event-buttons{
    display:flex;
    gap:10px;
    margin-top:20px;
}

.view-btn,
.register-btn{
    flex:1;
    border:none;
    text-align:center;
    text-decoration:none;
    padding:12px;
    border-radius:10px;
    font-weight:600;
    cursor:pointer;
}

.view-btn{
    background:#eef2ff;
    color:#2563eb;
}

.register-btn{
    background:#16a34a;
    color:white;
}

.register-btn:hover{
    background:#15803d;
}
</style>
</body>

</html>