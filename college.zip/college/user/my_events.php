<?php
session_start();
require "../db_connect.php";

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "
    SELECT e.*, r.*
    FROM event_registrations r
    INNER JOIN events e
        ON r.event_id = e.id
    WHERE r.user_id = '$user_id'
    ORDER BY e.event_date ASC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Events</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

    *{
        margin:0;
        padding:0;
        box-sizing:border-box;
        font-family:'Poppins',sans-serif;
    }

    body{
        background:#f4f7fb;
    }

    .header{
        background:#081229;
        color:white;
        text-align:center;
        padding:20px;
    }

    .container{
        width:90%;
        max-width:1000px;
        margin:40px auto;
    }

    .dash-card{
        background:white;
        padding:25px;
        margin-bottom:20px;
        border-radius:15px;
        box-shadow:0 5px 15px rgba(0,0,0,0.08);
    }

    .dash-card h3{
        margin-bottom:15px;
        color:#081229;
    }

    .dash-card p{
        margin:8px 0;
        color:#555;
    }

    .status-upcoming{
        color:green;
        font-weight:600;
    }

    .status-completed{
        color:gray;
        font-weight:600;
    }

    .back-btn{
        display:inline-block;
        margin-top:20px;
        padding:12px 20px;
        background:#2563eb;
        color:white;
        text-decoration:none;
        border-radius:8px;
    }

    .back-btn:hover{
        background:#1d4ed8;
    }

    .empty{
        text-align:center;
        background:white;
        padding:40px;
        border-radius:15px;
        box-shadow:0 5px 15px rgba(0,0,0,0.08);
    }

</style>

</head>

<body>

<div class="header">
    <h1>🎟 My Registered Events</h1>
</div>

<div class="container">

    <?php if(mysqli_num_rows($result) > 0): ?>

        <?php while($row = mysqli_fetch_assoc($result)): ?>

            <div class="dash-card">

                <h3>
                    <?= htmlspecialchars($row['event_name']) ?>
                </h3>

                <p>
                    <strong>Date:</strong>
                    <?= date('d M Y', strtotime($row['event_date'])) ?>
                </p>

                <p>
                    <strong>Members:</strong>
                    <?= $row['members'] ?? 1 ?>
                </p>

                <?php if(!empty($row['registration_code'])): ?>
                <p>
                    <strong>Registration Code:</strong>
                    <?= htmlspecialchars($row['registration_code']) ?>
                </p>
                <?php endif; ?>

                <?php if(!empty($row['event_location'])): ?>
                <p>
                    <strong>Location:</strong>
                    <?= htmlspecialchars($row['event_location']) ?>
                </p>
                <?php endif; ?>

                <?php if(!empty($row['event_category'])): ?>
                <p>
                    <strong>Category:</strong>
                    <?= htmlspecialchars($row['event_category']) ?>
                </p>
                <?php endif; ?>

                <?php if($row['event_date'] >= date('Y-m-d')): ?>

                    <p class="status-upcoming">
                        ✅ Upcoming Event
                    </p>

                <?php else: ?>

                    <p class="status-completed">
                        ✔ Completed Event
                    </p>

                <?php endif; ?>

            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <div class="empty">

            <h2>No Bookings Found</h2>

            <p>
                You haven't registered for any events yet.
            </p>

        </div>

    <?php endif; ?>

    <a href="dashboard.php" class="back-btn">
        ← Back to Dashboard
    </a>

</div>
```

</body>

</html>
