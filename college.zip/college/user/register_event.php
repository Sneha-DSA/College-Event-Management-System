<?php

session_start();
include "../db_connect.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$event_id = (int)($_GET['event_id'] ?? 0);

if($event_id <= 0){
    die("Invalid Event");
}

/* EVENT */

$eventQuery = mysqli_query(
    $conn,
    "SELECT * FROM events
     WHERE id='$event_id'"
);

if(mysqli_num_rows($eventQuery) == 0){
    die("Event Not Found");
}

$event = mysqli_fetch_assoc($eventQuery);

/* USER */

$userQuery = mysqli_query(
    $conn,
    "SELECT * FROM users
     WHERE id='$user_id'"
);

$user = mysqli_fetch_assoc($userQuery);

$success = "";
$error = "";

/* REGISTER */

if(isset($_POST['register'])){

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'])
    );

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        trim($_POST['mobile'])
    );

    $members = (int)$_POST['members'];

    $registration_code =
    mysqli_real_escape_string(
        $conn,
        trim($_POST['registration_code'])
    );

    /* CHECK DUPLICATE */

    $check = mysqli_query(
$conn,
"SELECT id
FROM event_registrations
WHERE user_id='$user_id'
AND event_id='$event_id'"
);


    if(mysqli_num_rows($check) > 0){

        $error =
        "You have already registered for this event.";

    }else{

        /* VALIDATE CODE */

        $couponCheck = mysqli_query(
            $conn,
            "SELECT *
             FROM coupons
             WHERE coupon_code='$registration_code'
             AND event_id='$event_id'"
        );

        if(mysqli_num_rows($couponCheck) == 0){

            $error =
            "Invalid Registration Code.";

        }else{

            $insert = mysqli_query(

$conn,

"INSERT INTO event_registrations
(
    event_id,
    user_id,
    student_name,
    student_email,
    student_mobile,
    members,
    registration_code
)
VALUES
(
    '$event_id',
    '$user_id',
    '$name',
    '$email',
    '$mobile',
    '$members',
    '$registration_code'
)"

);


            if($insert){

                header(
                    "Location: my_events.php?success=1"
                );

                exit();

            }else{

                $error =
                mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Register Event</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f7fb;
}

.container{
    width:90%;
    max-width:800px;
    margin:40px auto;
}

.hero{
    background:linear-gradient(
        135deg,
        #081229,
        #2563eb
    );
    color:white;
    padding:40px;
    border-radius:25px;
    margin-bottom:30px;
}

.hero h1{
    font-size:36px;
    margin-bottom:10px;
}

.form-card{
    background:white;
    padding:35px;
    border-radius:25px;
    box-shadow:
    0 10px 30px rgba(0,0,0,.08);
}

.event-info{
    background:#f3f4f6;
    padding:20px;
    border-radius:15px;
    margin-bottom:25px;
}

.event-info p{
    margin:10px 0;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

.form-group input{
    width:100%;
    padding:14px;
    border:2px solid #e5e7eb;
    border-radius:12px;
    outline:none;
}

.form-group input:focus{
    border-color:#2563eb;
}

.register-btn{
    width:100%;
    border:none;
    background:linear-gradient(
        135deg,
        #16a34a,
        #22c55e
    );
    color:white;
    padding:16px;
    border-radius:12px;
    cursor:pointer;
    font-size:16px;
    font-weight:600;
}

.success-box{
    background:#dcfce7;
    color:#166534;
    padding:15px;
    border-radius:12px;
    margin-bottom:20px;
}

.error-box{
    background:#fee2e2;
    color:#dc2626;
    padding:15px;
    border-radius:12px;
    margin-bottom:20px;
}

</style>

</head>

<body>

<div class="container">

    <div class="hero">

        <h1>🎉 Event Registration</h1>

        <p>
            Register for your selected event.
        </p>

    </div>

    <div class="form-card">

        <?php if($error){ ?>
        <div class="error-box">
            <?= $error ?>
        </div>
        <?php } ?>

        <div class="event-info">

            <p>
                <strong>Event:</strong>
                <?= htmlspecialchars(
                    $event['event_name']
                ) ?>
            </p>

            <p>
                <strong>Date:</strong>
                <?= date(
                    "d M Y",
                    strtotime(
                        $event['event_date']
                    )
                ) ?>
            </p>

            <p>
                <strong>Location:</strong>
                <?= htmlspecialchars(
                    $event['event_location']
                ) ?>
            </p>

        </div>

        <form method="POST">

            <div class="form-group">

                <label>Full Name</label>

                <input
                type="text"
                name="name"
                value="<?= htmlspecialchars($user['full_name']) ?>"
                readonly>

            </div>

            <div class="form-group">

                <label>Email</label>

                <input
                type="email"
                name="email"
                value="<?= htmlspecialchars($user['email']) ?>"
                readonly>

            </div>

            <div class="form-group">

                <label>Mobile Number</label>

                <input
                type="text"
                name="mobile"
                required>

            </div>

            <div class="form-group">

                <label>Members</label>

                <input
                type="number"
                name="members"
                value="1"
                min="1"
                required>

            </div>

            <div class="form-group">

                <label>Registration Code</label>

                <input
                type="text"
                name="registration_code"
                placeholder="Enter Event Code"
                required>

            </div>

            <button
            type="submit"
            name="register"
            class="register-btn">

                🚀 Register Now

            </button>

        </form>

    </div>

</div>

</body>
</html>